    SUBNETTING TOOL
    by Brody Tingle

    This is a simple, lightweight tool that can be used to help with subnetting.
    I created this while studying for my CCNA to help with problems and gain a deeper understanding
    of subnetting.

    To use the CLI:
        In the terminal, run:
            python3 cli.py
